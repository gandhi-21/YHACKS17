
/// Pets for 1/4 the miles of a usual
//  Extra person at 1/2 the miles of a usual


public class AddOns{
	
	public static void main(String[] args)
	{
		
	}
}