import java.util.Scanner;

//	Basic Benefits
// Redeemable benefits
// Use File to store
public class Benefits{
	
	public static void Base()
	{
	//	if(B.iseligible(B) == true)
		{
			System.out.println("Enjoy Complimanetary Benefits!: ");
			System.out.println("Free Checked Bags");
			System.out.println("Priority Boarding/Seating");
			System.out.println("Free Cabin Upgrades");
			System.out.println("Expediated Security");
			System.out.println("Lounge Acess");
			
		}
	//	else
	//		System.out.println("Not Eligible for Benefits! /n Talk to customer Service Please!");
	}
	public static void main(String[] args)
	{
	//	Scanner reader = new Scanner(System.in);
	//	System.out.println("Enter Identification no:");
	//	int number = reader.nextInt();
	//	// Search number in file for the object
	//	rewards r = new rewards();
	//	Benefits b = new Benefits(r);
	//	System.out.println("Checking for Benfits");
	//	Base(b);
	//	reader.close();
	}
}